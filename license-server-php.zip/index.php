<?php
// index.php - لوحة التحكم
session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>خادم التراخيص - نظام إدارة التراخيص</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>📜 خادم التراخيص</h1>
            <p>نظام إدارة التراخيص مع دعم REST API و WebSocket</p>
        </header>

        <!-- إحصائيات -->
        <div class="stats-grid" id="stats">
            <div class="stat-card">
                <div class="stat-icon">🔑</div>
                <div class="stat-info">
                    <h3 id="totalLicenses">0</h3>
                    <p>إجمالي التراخيص</p>
                </div>
            </div>
            <div class="stat-card success">
                <div class="stat-icon">✅</div>
                <div class="stat-info">
                    <h3 id="activeLicenses">0</h3>
                    <p>تراخيص نشطة</p>
                </div>
            </div>
            <div class="stat-card danger">
                <div class="stat-icon">⚠️</div>
                <div class="stat-info">
                    <h3 id="suspendedLicenses">0</h3>
                    <p>تراخيص معلقة</p>
                </div>
            </div>
            <div class="stat-card info">
                <div class="stat-icon">📱</div>
                <div class="stat-info">
                    <h3 id="activeDevices">0</h3>
                    <p>أجهزة نشطة</p>
                </div>
            </div>
        </div>

        <!-- نموذج إضافة ترخيص -->
        <div class="form-card">
            <h2>➕ إضافة ترخيص جديد</h2>
            <div class="form-grid">
                <input type="text" id="licenseKey" placeholder="مفتاح الترخيص" class="form-input">
                <input type="text" id="productName" placeholder="اسم المنتج" class="form-input">
                <input type="text" id="ownerName" placeholder="اسم المالك" class="form-input">
                <input type="email" id="ownerEmail" placeholder="البريد الإلكتروني" class="form-input">
                <input type="number" id="maxDevices" placeholder="الحد الأقصى للأجهزة" value="1" class="form-input">
                <input type="date" id="expiresAt" class="form-input">
                <input type="text" id="gameType" placeholder="نوع اللعبة" value="8ball" class="form-input">
                <input type="text" id="version" placeholder="الإصدار" value="1.0" class="form-input">
                <button id="addLicenseBtn" class="btn btn-primary">إضافة الترخيص</button>
            </div>
        </div>

        <!-- جدول التراخيص -->
        <div class="table-card">
            <h2>📋 قائمة التراخيص</h2>
            <div class="table-wrapper">
                <table id="licensesTable">
                    <thead>
                        <tr>
                            <th>مفتاح الترخيص</th>
                            <th>المنتج</th>
                            <th>المالك</th>
                            <th>HWID</th>
                            <th>الحالة</th>
                            <th>تاريخ الانتهاء</th>
                            <th>الإصدار</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody id="licensesTableBody">
                        <tr><td colspan="8" class="loading">جاري التحميل...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
</body>
</html>