const API_BASE = '/api';

async function loadStats() {
    try {
        const response = await fetch(`${API_BASE}/stats`);
        const stats = await response.json();
        
        document.getElementById('totalLicenses').textContent = stats.total_licenses || 0;
        document.getElementById('activeLicenses').textContent = stats.active_licenses || 0;
        document.getElementById('suspendedLicenses').textContent = stats.suspended_licenses || 0;
        document.getElementById('activeDevices').textContent = stats.active_sessions || 0;
    } catch (error) {
        console.error('Error:', error);
    }
}

async function loadLicenses() {
    try {
        const response = await fetch(`${API_BASE}/licenses`);
        const licenses = await response.json();
        
        const tbody = document.getElementById('licensesTableBody');
        
        if (licenses.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="loading">لا توجد تراخيص</td></tr>';
            return;
        }
        
        tbody.innerHTML = licenses.map(license => `
            <tr>
                <td><code>${escapeHtml(license.license_key)}</code></td>
                <td>${escapeHtml(license.product_name)}</td>
                <td>${escapeHtml(license.owner_name)}<br><small>${escapeHtml(license.owner_email)}</small></td>
                <td><code>${license.hwid ? license.hwid.substring(0, 16) + '...' : 'غير مفعل'}</code></td>
                <td><span class="status-badge ${license.status === 'active' ? 'status-active' : 'status-suspended'}">${license.status === 'active' ? 'نشط' : 'موقوف'}</span></td>
                <td>${license.expires_at ? new Date(license.expires_at).toLocaleDateString('ar-EG') : 'غير محدد'}</td>
                <td>${license.version || '1.0'}</td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="toggleStatus('${license.license_key}', '${license.status}')">${license.status === 'active' ? 'إيقاف' : 'تفعيل'}</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteLicense('${license.license_key}')">حذف</button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error:', error);
    }
}

async function addLicense() {
    const license_key = document.getElementById('licenseKey').value.trim();
    const product_name = document.getElementById('productName').value.trim();
    const owner_name = document.getElementById('ownerName').value.trim();
    const owner_email = document.getElementById('ownerEmail').value.trim();
    const max_devices = parseInt(document.getElementById('maxDevices').value) || 1;
    const expires_at = document.getElementById('expiresAt').value;
    const game_type = document.getElementById('gameType').value.trim() || '8ball';
    const version = document.getElementById('version').value.trim() || '1.0';
    
    if (!license_key || !product_name || !owner_name || !owner_email) {
        alert('الرجاء ملء جميع الحقول المطلوبة');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/licenses`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                license_key, product_name, owner_name, owner_email,
                max_devices, expires_at, game_type, version
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('تم إضافة الترخيص بنجاح');
            document.getElementById('licenseKey').value = '';
            document.getElementById('productName').value = '';
            document.getElementById('ownerName').value = '';
            document.getElementById('ownerEmail').value = '';
            loadStats();
            loadLicenses();
        } else {
            alert('خطأ: ' + (result.error || 'فشل إضافة الترخيص'));
        }
    } catch (error) {
        alert('خطأ في الاتصال بالخادم');
    }
}

async function toggleStatus(licenseKey, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'suspended' : 'active';
    
    try {
        const response = await fetch(`${API_BASE}/licenses/${licenseKey}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });
        
        const result = await response.json();
        
        if (result.success) {
            loadStats();
            loadLicenses();
        } else {
            alert('فشل تحديث حالة الترخيص');
        }
    } catch (error) {
        alert('خطأ في الاتصال بالخادم');
    }
}

async function deleteLicense(licenseKey) {
    if (!confirm('هل أنت متأكد من حذف هذا الترخيص؟')) return;
    
    try {
        const response = await fetch(`${API_BASE}/licenses/${licenseKey}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.success) {
            loadStats();
            loadLicenses();
        } else {
            alert('فشل حذف الترخيص');
        }
    } catch (error) {
        alert('خطأ في الاتصال بالخادم');
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Event listeners
document.getElementById('addLicenseBtn').addEventListener('click', addLicense);

// Initial load
loadStats();
loadLicenses();

// Refresh every 10 seconds
setInterval(() => {
    loadStats();
    loadLicenses();
}, 10000);