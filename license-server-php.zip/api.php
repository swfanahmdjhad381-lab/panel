<?php
// api.php - نقطة نهاية API
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ============ REST API Routes ============

// GET /api/stats - الإحصائيات
if ($method === 'GET' && $path === '/api/stats') {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_licenses,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_licenses,
            SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended_licenses,
            SUM(CASE WHEN hwid IS NOT NULL THEN 1 ELSE 0 END) as activated_devices,
            (SELECT COUNT(DISTINCT hwid) FROM active_devices) as active_sessions
        FROM licenses
    ");
    echo json_encode($stmt->fetch());
    exit();
}

// GET /api/licenses - قائمة التراخيص
if ($method === 'GET' && $path === '/api/licenses') {
    $stmt = $pdo->query("SELECT * FROM licenses ORDER BY created_at DESC");
    echo json_encode($stmt->fetchAll());
    exit();
}

// POST /api/licenses - إضافة ترخيص
if ($method === 'POST' && $path === '/api/licenses') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $license_key = $data['license_key'] ?? '';
    $product_name = $data['product_name'] ?? '';
    $owner_name = $data['owner_name'] ?? '';
    $owner_email = $data['owner_email'] ?? '';
    $max_devices = $data['max_devices'] ?? 1;
    $expires_at = $data['expires_at'] ?? date('Y-m-d H:i:s', strtotime('+1 year'));
    $game_type = $data['game_type'] ?? '8ball';
    $version = $data['version'] ?? '1.0';
    
    if (!$license_key || !$product_name || !$owner_name || !$owner_email) {
        http_response_code(400);
        echo json_encode(['error' => 'جميع الحقول مطلوبة']);
        exit();
    }
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO licenses (license_key, product_name, owner_name, owner_email, max_devices, expires_at, game_type, version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$license_key, $product_name, $owner_name, $owner_email, $max_devices, $expires_at, $game_type, $version]);
        echo json_encode(['success' => true, 'message' => 'تم إضافة الترخيص']);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'مفتاح الترخيص موجود مسبقاً']);
    }
    exit();
}

// PUT /api/licenses/{license_key} - تحديث ترخيص
if ($method === 'PUT' && preg_match('/^\/api\/licenses\/(.+)$/', $path, $matches)) {
    $license_key = $matches[1];
    $data = json_decode(file_get_contents('php://input'), true);
    
    $fields = [];
    $values = [];
    $allowed = ['status', 'hwid', 'max_devices', 'expires_at', 'version'];
    
    foreach ($allowed as $field) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $values[] = $data[$field];
        }
    }
    
    if (empty($fields)) {
        http_response_code(400);
        echo json_encode(['error' => 'لا توجد بيانات للتحديث']);
        exit();
    }
    
    $values[] = $license_key;
    $stmt = $pdo->prepare("UPDATE licenses SET " . implode(', ', $fields) . " WHERE license_key = ?");
    $updated = $stmt->execute($values);
    
    echo json_encode(['success' => $updated]);
    exit();
}

// DELETE /api/licenses/{license_key} - حذف ترخيص
if ($method === 'DELETE' && preg_match('/^\/api\/licenses\/(.+)$/', $path, $matches)) {
    $license_key = $matches[1];
    $stmt = $pdo->prepare("DELETE FROM licenses WHERE license_key = ?");
    $deleted = $stmt->execute([$license_key]);
    
    echo json_encode(['success' => $deleted]);
    exit();
}

// POST /api/verify - التحقق من الترخيص (لـ REST)
if ($method === 'POST' && $path === '/api/verify') {
    $data = json_decode(file_get_contents('php://input'), true);
    $license_key = $data['license_key'] ?? '';
    $hwid = $data['hwid'] ?? '';
    
    if (!$license_key || !$hwid) {
        echo json_encode(['success' => false, 'error' => 'license_key و hwid مطلوبين']);
        exit();
    }
    
    $license = getLicense($pdo, $license_key);
    
    if (!$license) {
        echo json_encode(['success' => false, 'valid' => false, 'error' => 'الترخيص غير موجود']);
        exit();
    }
    
    if ($license['status'] !== 'active') {
        echo json_encode(['success' => false, 'valid' => false, 'error' => 'الترخيص معطل']);
        exit();
    }
    
    $now = new DateTime();
    $expires = new DateTime($license['expires_at']);
    
    if ($expires < $now) {
        echo json_encode(['success' => false, 'valid' => false, 'error' => 'انتهت صلاحية الترخيص']);
        exit();
    }
    
    $firstActivation = false;
    if (empty($license['hwid'])) {
        updateLicense($pdo, $license_key, ['hwid' => $hwid, 'last_used' => date('Y-m-d H:i:s'), 'active_devices' => 1]);
        $firstActivation = true;
    } elseif ($license['hwid'] !== $hwid) {
        echo json_encode(['success' => false, 'valid' => false, 'error' => 'الجهاز غير مصرح به']);
        exit();
    } else {
        updateLicense($pdo, $license_key, ['last_used' => date('Y-m-d H:i:s')]);
    }
    
    addLog($pdo, $license_key, 'verify_success');
    
    echo json_encode([
        'success' => true,
        'valid' => true,
        'license_key' => $license['license_key'],
        'product_name' => $license['product_name'],
        'expires_at' => $license['expires_at'],
        'first_activation' => $firstActivation,
        'version' => $license['version']
    ]);
    exit();
}

// POST /api/websocket - نقطة نهاية WebSocket عبر HTTP (للمشاركة)
if ($method === 'POST' && $path === '/api/websocket') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // تسجيل العميل
    if (isset($data['register']) && $data['register'] === true) {
        if (($data['token'] ?? '') !== WS_TOKEN) {
            echo json_encode(['success' => false, 'error' => 'Invalid token']);
            exit();
        }
        echo json_encode(['success' => true, 'message' => 'Registered']);
        exit();
    }
    
    // مصادقة
    if (isset($data['token']) && $data['token'] === WS_TOKEN && isset($data['data'])) {
        $decrypted = decryptRequest($data['data'], ENCRYPTION_KEY);
        
        if (!$decrypted) {
            echo json_encode(['data' => encryptResponse(json_encode(['status' => 'error', 'message' => 'Decryption failed']), ENCRYPTION_KEY)]);
            exit();
        }
        
        $authData = json_decode($decrypted, true);
        $license_key = $authData['license_key'] ?? '';
        $hwid = $authData['hwid'] ?? '';
        $version = $authData['version'] ?? '';
        
        $license = getLicense($pdo, $license_key);
        
        if (!$license) {
            $response = json_encode(['status' => 'error', 'message' => 'Invalid license key']);
            echo json_encode(['data' => encryptResponse($response, ENCRYPTION_KEY)]);
            exit();
        }
        
        if ($license['status'] !== 'active') {
            $response = json_encode(['status' => 'error', 'message' => 'License suspended']);
            echo json_encode(['data' => encryptResponse($response, ENCRYPTION_KEY)]);
            exit();
        }
        
        $now = new DateTime();
        $expires = new DateTime($license['expires_at']);
        
        if ($expires < $now) {
            $response = json_encode(['status' => 'error', 'message' => 'License expired']);
            echo json_encode(['data' => encryptResponse($response, ENCRYPTION_KEY)]);
            exit();
        }
        
        if (empty($license['hwid'])) {
            updateLicense($pdo, $license_key, ['hwid' => $hwid, 'last_used' => date('Y-m-d H:i:s')]);
        } elseif ($license['hwid'] !== $hwid) {
            $response = json_encode(['status' => 'error', 'message' => 'HWID mismatch']);
            echo json_encode(['data' => encryptResponse($response, ENCRYPTION_KEY)]);
            exit();
        }
        
        $successResponse = json_encode([
            'status' => 'success',
            'message' => 'License valid',
            'data' => [
                'license_key' => $license['license_key'],
                'expiry_date' => $license['expires_at'],
                'version' => $license['version'],
                'max_devices' => $license['max_devices'],
                'active_devices' => $license['active_devices'],
                'auth_token' => '0wQRlDkgoQlf'
            ]
        ]);
        
        echo json_encode(['data' => encryptResponse($successResponse, ENCRYPTION_KEY)]);
        exit();
    }
    
    http_response_code(400);
    echo json_encode(['error' => 'Bad request']);
    exit();
}

// إذا لم يجد أي مسار
http_response_code(404);
echo json_encode(['error' => 'Not found']);
?>