<?php
// db.php - اتصال قاعدة البيانات
header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('Asia/Riyadh');

$db_host = 'localhost';     // أو عنوان الاستضافة
$db_name = 'license_system';
$db_user = 'root';          // غير حسب استضافتك
$db_pass = '';              // غير حسب استضافتك

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
}

// دوال مساعدة
function getLicense($pdo, $license_key) {
    $stmt = $pdo->prepare("SELECT * FROM licenses WHERE license_key = ?");
    $stmt->execute([$license_key]);
    return $stmt->fetch();
}

function updateLicense($pdo, $license_key, $data) {
    $fields = [];
    $values = [];
    foreach ($data as $key => $value) {
        $fields[] = "$key = ?";
        $values[] = $value;
    }
    $values[] = $license_key;
    $stmt = $pdo->prepare("UPDATE licenses SET " . implode(', ', $fields) . " WHERE license_key = ?");
    return $stmt->execute($values);
}

function addLog($pdo, $license_key, $action) {
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $stmt = $pdo->prepare("INSERT INTO logs (license_key, action, ip_address, user_agent) VALUES (?, ?, ?, ?)");
    $stmt->execute([$license_key, $action, $ip, $user_agent]);
}

// دوال التشفير (متطابقة مع كود C++)
function xorEncrypt($data, $key) {
    $result = '';
    $keyLen = strlen($key);
    for ($i = 0; $i < strlen($data); $i++) {
        $result .= chr(ord($data[$i]) ^ ord($key[$i % $keyLen]));
    }
    return $result;
}

function xorDecrypt($data, $key) {
    return xorEncrypt($data, $key);
}

function base64Encode($data) {
    return base64_encode($data);
}

function base64Decode($data) {
    return base64_decode($data);
}

function encryptResponse($data, $key) {
    $encrypted = xorEncrypt($data, $key);
    return base64Encode($encrypted);
}

function decryptRequest($encryptedData, $key) {
    $decoded = base64Decode($encryptedData);
    if ($decoded === false) return null;
    return xorDecrypt($decoded, $key);
}

// مفاتيح التشفير (نفس الموجودة في كود C++)
define('ENCRYPTION_KEY', 'JiM21rNU12eERlNmpqa3FuQks');
define('WS_TOKEN', 'KJGMDKFJDHG34KD');
?>